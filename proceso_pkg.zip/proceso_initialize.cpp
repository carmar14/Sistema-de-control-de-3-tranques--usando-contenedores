//
// File: proceso_initialize.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 26-Aug-2020 16:50:32
//

// Include Files
#include "rt_nonfinite.h"
#include "proceso.h"
#include "proceso_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void proceso_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for proceso_initialize.cpp
//
// [EOF]
//
