//
// File: proceso_terminate.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 26-Aug-2020 16:50:32
//

// Include Files
#include "rt_nonfinite.h"
#include "proceso.h"
#include "proceso_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void proceso_terminate()
{
  // (no terminate code required)
}

//
// File trailer for proceso_terminate.cpp
//
// [EOF]
//
