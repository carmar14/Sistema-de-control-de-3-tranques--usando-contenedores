//
// File: proceso_terminate.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 26-Aug-2020 16:50:32
//
#ifndef PROCESO_TERMINATE_H
#define PROCESO_TERMINATE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "proceso_types.h"

// Function Declarations
extern void proceso_terminate();

#endif

//
// File trailer for proceso_terminate.h
//
// [EOF]
//
