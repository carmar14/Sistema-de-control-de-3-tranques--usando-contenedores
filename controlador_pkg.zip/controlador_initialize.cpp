//
// File: controlador_initialize.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 26-Aug-2020 16:37:14
//

// Include Files
#include "rt_nonfinite.h"
#include "controlador.h"
#include "controlador_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void controlador_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for controlador_initialize.cpp
//
// [EOF]
//
