//
// File: controlador_terminate.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 26-Aug-2020 16:37:14
//
#ifndef CONTROLADOR_TERMINATE_H
#define CONTROLADOR_TERMINATE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "controlador_types.h"

// Function Declarations
extern void controlador_terminate();

#endif

//
// File trailer for controlador_terminate.h
//
// [EOF]
//
