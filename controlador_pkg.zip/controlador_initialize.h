//
// File: controlador_initialize.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 26-Aug-2020 16:37:14
//
#ifndef CONTROLADOR_INITIALIZE_H
#define CONTROLADOR_INITIALIZE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "controlador_types.h"

// Function Declarations
extern void controlador_initialize();

#endif

//
// File trailer for controlador_initialize.h
//
// [EOF]
//
