//
// File: controlador_terminate.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 26-Aug-2020 16:37:14
//

// Include Files
#include "rt_nonfinite.h"
#include "controlador.h"
#include "controlador_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void controlador_terminate()
{
  // (no terminate code required)
}

//
// File trailer for controlador_terminate.cpp
//
// [EOF]
//
